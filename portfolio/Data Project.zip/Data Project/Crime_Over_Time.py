import matplotlib.pyplot as plt
import os.path

'''How crime relates to poverty. Create a visualization - a scatterplot of
crime rates versus poverty stats'''

# Naming the current directory
directory = os.path.dirname(os.path.abspath(__file__))  
filename = os.path.join(directory, 'crime_raw_data.txt')

# Create lists for x and y values
years=[]
violent_crime_rates=[]

#stores the data in the file and skips lines 1-4
datafile = open(filename,'r') # 'r' means 'read-only'
next(datafile)
next(datafile)
next(datafile)
next(datafile)

# For each line in the file...
for line in datafile:
    # Split the line into the three separate pieces of info
    year, population, viol_crime, rate = line.split('\t')
    years += [year]
    violent_crime_rates += [rate[0:-1]]
datafile.close()

#Create bar graph and show
fig, ax = plt.subplots(1,1)
ax.bar(years, violent_crime_rates)
ax.set_ylabel('Violent Crime Rate')
ax.set_xlabel('Year')
ax.set_title('Violent Crime Over Time')
fig.show()